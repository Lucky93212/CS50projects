#include <stdio.h>
#include <cs50.h>

int main(void)
{
    long cardn = get_long("Number: ");
    int digits = 0;
    int digits2 = 0;
    long con = cardn;
    long no1 = (cardn)-((cardn/10)*10);
    long no2 = (cardn/10)-((cardn/100)*10);
    long no3 = (cardn/100)-((cardn/1000)*10);
    long no4 = (cardn/1000)-((cardn/10000)*10);
    long no5 = (cardn/10000)-((cardn/100000)*10);
    long no6 = (cardn/100000)-((cardn/1000000)*10);
    long no7 = (cardn/1000000)-((cardn/10000000)*10);
    long no8 = (cardn/10000000)-((cardn/100000000)*10);
    long no9 = (cardn/100000000)-((cardn/1000000000)*10);
    long no10 = (cardn/1000000000)-((cardn/10000000000)*10);
    long no11 = (cardn/10000000000)-((cardn/100000000000)*10);
    long no12 = (cardn/100000000000)-((cardn/1000000000000)*10);
    long no13 = (cardn/1000000000000)-((cardn/10000000000000)*10);
    long no14 = (cardn/10000000000000)-((cardn/100000000000000)*10);
    long no15 = (cardn/100000000000000)-((cardn/1000000000000000)*10);
    long no16 = (cardn/1000000000000000)-((cardn/10000000000000000)*10);
    long x1 = (no2*2) - (((no2*2)/10)*10);
    long x2 = (no2*2)/10;
    long x3 = (no4*2) - (((no4*2)/10)*10);
    long x4 = (no4*2)/10;
    long x5 = (no6*2) - (((no6*2)/10)*10);
    long x6 = (no6*2)/10;
    long x7 = (no8*2) - (((no8*2)/10)*10);
    long x8 = (no8*2)/10;
    long x9 = (no10*2) - (((no10*2)/10)*10);
    long x10 = (no10*2)/10;
    long x11 = (no12*2) - (((no12*2)/10)*10);
    long x12 = (no12*2)/10;
    long x13 = (no14*2) - (((no14*2)/10)*10);
    long x14 = (no14*2)/10;
    long x15 = (no16*2) - (((no16*2)/10)*10);
    long x16 = (no16*2)/10;
    int cardsum = no1 + no3 + no5 + no7 + no9 + no11 + no13 + no15 + x1 + x2 + x3 + x4 + x5 + x6 + x7 + x8 + x9 + x10 + x11 + x12 + x13 + x14 + x15 + x16;

    while(con > 1)
    {
        con = con/10;
        digits++;
    }

    long con2 = cardn;
    long con3 = cardn;

    for(int i = 0; i < (digits - 1); i++)
    {
        con2 = con2/10;
    }
    for(int j = 0; j < (digits - 2); j++)
    {
        con3 = con3/10;
    }

    if(digits == 13 || digits == 14)
    {

        if(con2 - 4 == 0)
        {
            if((cardsum - ((cardsum/10)*10)) == 0)
            {
                printf("VISA\n");
            }
            else
            {
                printf("INVALID\n");
            }
        }
        else
        {
            printf("INVALID\n");
        }
    }
    else if(digits == 15)
    {
        if(con2 - 4 == 0)
        {
            if((cardsum - ((cardsum/10)*10)) == 0)
            {
                printf("VISA\n");
            }
            else
            {
                printf("INVALID\n");
            }
        }
        else if(con2 - 3 == 0)
        {
            if((con3 - (con2*10)) == 4 ||(con3 - (con2*10)) == 7)
            {
                if((cardsum - ((cardsum/10)*10)) == 0)
                {
                    printf("AMEX\n");
                }
                else
                {
                    printf("INVALID\n");
                }
            }
            else
            {
                printf("INVALID\n");  
            }
        }
        else
        {
            printf("INVALID\n");
        }
    }
    else if(digits == 16)
    {
        if(con2 - 4 == 0)
        {
            if((cardsum - ((cardsum/10)*10)) == 0)
            {
                printf("VISA\n");
            }
            else
            {
                printf("INVALID\n");
            }
        }
        else if(con2 - 5 == 0)
        {
            if((con3 - (con2*10)) == 1 ||(con3 - (con2*10)) == 2 ||(con3 - (con2*10)) == 3 ||(con3 - (con2*10)) == 4 ||(con3 - (con2*10)) == 5)
            {
                if((cardsum - ((cardsum/10)*10)) == 0)
                {
                    printf("MASTERCARD\n");
                }
                else
                {
                    printf("INVALID\n");
                }
            }
            else
            {
                printf("INVALID\n");
            }
        }
        else
        {
            printf("INVALID\n");
        }
    }
    else
    {
        printf("INVALID\n");
    }
}
#include <stdio.h>
#include <cs50.h>
#include <math.h>

int main(void)
{
    float change;
    
    do
    {
         change = get_float("Change owed: ");
    }
    while(change < 0);
    
    int cents = round(change * 100);
    
    int coins = 0;

    while(cents > 24)
    {
        cents = cents - 25;
        coins++;
    }
    if(cents > 0)
    {
        while(cents > 9)
        {
            cents = cents - 10;
            coins++;
        }
        if(cents > 0)
        {
            while(cents > 4)
            {
                cents = cents - 5;
                coins++;
            }
            if(cents > 0)
            {
                while(cents > 0)
                {
                    cents = cents - 1;
                    coins++;
                }
                
                printf("%i\n", coins);
                
            }
            else
            {
                printf("%i\n", coins);
            }
        }
        else
        {
            printf("%i\n", coins);
        }
        
    }
    else
    {
        printf("%i\n", coins);
    }
}
#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <math.h>

int main(void)
{
    string s = get_string("Text: ");
    float letters = 0;
    float sentences = 0;
    float words = 0;
    
    for(int i = 0, n = strlen(s); i < n; i++)
    {
        if((s[i] >= 'a' && s[i] <= 'z') || (s[i] >= 'A' && s[i] <= 'Z'))
        {
            letters++;
        }
    }
    
    for(int y = 0, n = strlen(s); y < n; y++)
    {
        if(s[y] == '.' || s[y] == '?' || s[y] == '!')
        {
            sentences++;
        }
    }
    
    for(int x = 0, n = strlen(s); x < n; x++)
    {
        if(s[x] == ' ')
        {
            words++;
        }
    }
    words = words + 1;
    
    float multiplier = 100/words;
    letters = letters*multiplier;
    sentences = sentences*multiplier;
    
    float index = 0.0588 * letters - 0.296 * sentences - 15.8;
    index = round(index);
    if(index < 1)
    {
        printf("Before Grade 1\n");
    }
    else if(index > 16)
    {
        printf("Grade 16+\n");
    }
    else
    {
        printf("Grade %.0f\n", index);
    }
}
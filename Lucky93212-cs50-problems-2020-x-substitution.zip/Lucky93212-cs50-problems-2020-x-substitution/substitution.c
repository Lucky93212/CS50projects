#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <math.h>

int main(int argc, string argv[])
{
    if(argc != 2)
    {
        printf("Usage: ./substitution key\n");
        return 1;
    }

    string s = argv[1];
    
    if(strlen(s) != 26)
    {
        printf("Usage: ./substitution key\n");
        return 1;
    }

    for(int i = 0; i < 26; i++)
    {
        if(s[i] != 'A' && s[i] != 'B' && s[i] != 'C' && s[i] != 'D' && s[i] != 'E' && s[i] != 'F' && s[i] != 'G' && s[i] != 'H' && s[i] != 'I' && s[i] != 'J' && s[i] != 'K' && s[i] != 'L' && s[i] != 'M' && s[i] != 'N' && s[i] != 'O' && s[i] != 'P' && s[i] != 'Q' && s[i] != 'R' && s[i] != 'S' && s[i] != 'T' && s[i] != 'U' && s[i] != 'V' && s[i] != 'W' && s[i] != 'X' && s[i] != 'Y' && s[i] != 'Z' && s[i] != 'a' && s[i] != 'b' && s[i] != 'c' && s[i] != 'd' && s[i] != 'e' && s[i] != 'f' && s[i] != 'g' && s[i] != 'h' && s[i] != 'i' && s[i] != 'j' && s[i] != 'k' && s[i] != 'l' && s[i] != 'm' && s[i] != 'n' && s[i] != 'o' && s[i] != 'p' && s[i] != 'q' && s[i] != 'r' && s[i] != 's' && s[i] != 't' && s[i] != 'u' && s[i] != 'v' && s[i] != 'w' && s[i] != 'x' && s[i] != 'y' && s[i] != 'z')
        {
            printf("Usage: ./substitution key\n");
            return 1;
        }
    }
    
    for(int x = 0; x < 26; x++)
    {
        for(int y = x + 1; y < 26; y++)
        {
            if(s[x] == s[y])
            {
                printf("Usage: ./substitution key\n");
                return 1;
            }
        }
    }
    string plaintext = get_string("plaintext: ");
    printf("ciphertext: ");

    for(int z = 0, a = strlen(plaintext); z < a; z++)
    {
        if(plaintext[z] >= 'a' && plaintext[z] <= 'z')
        {
            if(s[plaintext[z] - 97] >= 'a' && s[plaintext[z] - 97] <= 'z')
            {
                printf("%c", s[plaintext[z] - 97]);
            }
            else
            {
                printf("%c", s[plaintext[z] - 97] + 32);
            }
        }
        else if(plaintext[z] >= 'A' && plaintext[z] <= 'Z')
        {
            if(s[plaintext[z] - 65] >= 'A' && s[plaintext[z] - 65] <= 'Z')
            {
                printf("%c", s[plaintext[z] - 65]);
            }
            else
            {
                printf("%c", s[plaintext[z] - 65] - 32);
            }
        }
        else
        {
            printf("%c", plaintext[z]);
        }
    }
    printf("\n");
}
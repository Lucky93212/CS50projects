#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <math.h>

int main(int argc, string argv[])
{
    if(argc != 2)
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }

    string s = argv[1];

    for(int i = 0, n = strlen(s); i < n; i++)
    {
        if(s[i] != '1' && s[i] != '2' && s[i] != '3' && s[i] != '4' && s[i] != '5' && s[i] != '6' && s[i] != '7' && s[i] != '8' && s[i] != '9')
        {
            printf("Usage: ./caesar key\n");
            return 1;
        }
    }
    int k = 0;
    int n = strlen(s);
    int z = n - 1;
    
    for(int y = 0; y < n; y++)
    {
        if(s[y] == '1')
        {
            k = k + pow(10, z);
        }
        else if(s[y] == '2')
        {
            k = k + 2*pow(10, z);
        }
        else if(s[y] == '3')
        {
            k = k + 3*pow(10, z);
        }
        else if(s[y] == '4')
        {
            k = k + 4*pow(10, z);
        }
        else if(s[y] == '5')
        {
            k = k + 5*pow(10, z);
        }
        else if(s[y] == '6')
        {
            k = k + 6*pow(10, z);
        }
        else if(s[y] == '7')
        {
            k = k + 7*pow(10, z);
        }
        else if(s[y] == '8')
        {
            k = k + 8*pow(10, z);
        }
        else
        {
            k = k + 9*pow(10, z);
        }
        z = z - 1;
    }
    k = k % 26;
    string plaintext = get_string("plaintext: ");
    printf("ciphertext: ");
    
    for(int x = 0, a = strlen(plaintext); x < a; x++)
    {
        if((plaintext[x] >= 'A' && plaintext[x] <= 'Z'))
        {
            if((plaintext[x] + k) > 90)
            {
                printf("%c", (plaintext[x] + k) - 26);
            }
            else
            {
                printf("%c", (plaintext[x] + k));
            }
        }
        else if((plaintext[x] >= 'a' && plaintext[x] <= 'z'))
        {
            if((plaintext[x] + k) > 122)
            {
                printf("%c", (plaintext[x] + k) - 26);
            }
            else
            {
                printf("%c", (plaintext[x] + k));
            }
        }
        else
        {
            printf("%c", plaintext[x]);
        }
    }
    printf("\n");
}
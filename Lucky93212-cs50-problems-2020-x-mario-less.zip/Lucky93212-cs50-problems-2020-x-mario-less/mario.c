#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int height;
    int h = 0;
    int w = 0;
    int i = 0;
    int d = 0;
    
    do
    {
        height = get_int("Height: ");
        d = height - 1;

    }
    while(height < 1 || height > 8);
    
    while(h < height)
    {
        while(i < d)
        {
            printf(" ");
            i++;
        }
            
        while(w <= h)
        {
            printf("#");
            w++;
        }
        
        printf("\n");
        h++;
        i = 0;
        w = 0;
        d = d - 1;
    }
}